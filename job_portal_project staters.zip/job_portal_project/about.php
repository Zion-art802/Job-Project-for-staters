<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>About Us - Job Portal</title>
    <link rel="stylesheet" href="style/style.css">

</head>
<body>
    <h2>About Job Portal</h2>
    <p>Welcome to JobPortal – your go-to platform for connecting job seekers with top employers. Our mission is to simplify the hiring process and help individuals find meaningful careers.</p>
    <p>We provide a wide range of job listings, application tracking, and employer reviews to help users make informed decisions.</p>
    <a href="index.php">Back to Home</a>
</body>
</html>
