<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Get job ID from URL and validate
$job_id = isset($_GET['job_id']) ? (int)$_GET['job_id'] : 0;
if ($job_id <= 0) {
    die("Invalid job ID.");
}

// Check if job exists
$stmt = $conn->prepare("SELECT title FROM jobs WHERE id = ?");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    $stmt->close();
    die("Job not found.");
}

$stmt->bind_result($job_title);
$stmt->fetch();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if already applied
    $checkStmt = $conn->prepare("SELECT id FROM applications WHERE user_id = ? AND job_id = ?");
    $checkStmt->bind_param("ii", $user_id, $job_id);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        $_SESSION['apply_error'] = "You have already applied for this job.";
        header("Location: apply.php?job_id=$job_id");
        exit;
    }
    $checkStmt->close();

    // Insert application
    $insertStmt = $conn->prepare("INSERT INTO applications (user_id, job_id) VALUES (?, ?)");
    $insertStmt->bind_param("ii", $user_id, $job_id);

    if ($insertStmt->execute()) {
        $_SESSION['apply_success'] = "Application submitted successfully for \"$job_title\".";
    } else {
        $_SESSION['apply_error'] = "Failed to submit application. Please try again.";
    }
    $insertStmt->close();

    header("Location: apply.php?job_id=$job_id");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply for Job</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            padding: 30px;
            text-align: center;
        }
        .container {
            background: white;
            padding: 25px;
            border-radius: 12px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        button {
            background: #007BFF;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 15px;
        }
        button:hover {
            background: #0056b3;
        }
        .success {
            color: green;
            font-weight: bold;
            margin-top: 15px;
        }
        .error {
            color: red;
            font-weight: bold;
            margin-top: 15px;
        }
        a.back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007BFF;
        }
        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Apply for Job: <?= htmlspecialchars($job_title) ?></h2>

        <?php
        if (isset($_SESSION['apply_error'])) {
            echo '<p class="error">' . $_SESSION['apply_error'] . '</p>';
            unset($_SESSION['apply_error']);
        }
        if (isset($_SESSION['apply_success'])) {
            echo '<p class="success">' . $_SESSION['apply_success'] . '</p>';
            unset($_SESSION['apply_success']);
        }
        ?>

        <form method="POST">
            <button type="submit">Submit Application</button>
        </form>

        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
