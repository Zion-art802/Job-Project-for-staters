<?php
session_start();
require 'db.php'; // DB connection file

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize inputs
    $fname = htmlspecialchars($_POST['fname'] ?? '');
    $lname = htmlspecialchars($_POST['lname'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validate inputs
    if (!$fname) {
        $_SESSION['error'] = "First name required";
        header("Location: signup.php");
        exit;
    }
    if (!$lname) {
        $_SESSION['error'] = "Last name required";
        header("Location: signup.php");
        exit;
    }
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Valid email required";
        header("Location: signup.php");
        exit;
    }
    if (!$password || strlen($password) < 6) {
        $_SESSION['error'] = "Password must be at least 6 characters";
        header("Location: signup.php");
        exit;
    }

    // Check if email exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $_SESSION['error'] = "Email already registered";
        $stmt->close();
        header("Location: signup.php");
        exit;
    }
    $stmt->close();

    // Hash password
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Insert user
    $stmt = $conn->prepare("INSERT INTO users (fname, lname, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $fname, $lname, $email, $passwordHash);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: login.php?registered=1");
        exit;
    } else {
        $_SESSION['error'] = "Registration failed. Try again.";
        header("Location: signup.php");
        exit;
    }
} else {
    header("Location: signup.php");
    exit;
}
?>
