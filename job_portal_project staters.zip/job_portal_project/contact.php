<?php session_start(); ?>
<!DOCTYPE html>
<link rel="stylesheet" href="style/style.css">
<html>
<head>
    <title>Contact Us</title>
    <style>
      .error { color: red; }
      .success { color: green; }
    </style>
</head>
<body>

<h2>Contact Us</h2>

<?php
if (isset($_SESSION['contact_success'])) {
    echo '<p class="success">' . $_SESSION['contact_success'] . '</p>';
    unset($_SESSION['contact_success']);
}

if (isset($_SESSION['contact_error'])) {
    echo '<p class="error">' . $_SESSION['contact_error'] . '</p>';
    unset($_SESSION['contact_error']);
}
?>

<form action="contact_process.php" method="POST">
    <input type="text" name="name" placeholder="Your Name" required><br><br>
    <input type="email" name="email" placeholder="Your Email" required><br><br>
    <textarea name="message" placeholder="Your Message" rows="5" cols="30" required></textarea><br><br>
    <button type="submit">Send Message</button>
</form>

</body>
</html>
