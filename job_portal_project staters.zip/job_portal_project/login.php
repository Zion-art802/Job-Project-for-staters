<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <h2>Login</h2>
    <form action="loginProc.php" method="POST">
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>

    <?php
    if (isset($_SESSION['error'])) {
        echo '<p class="error">' . $_SESSION['error'] . '</p>';
        unset($_SESSION['error']);
    }
    if (isset($_GET['registered'])) {
        echo '<p class="success">Registration successful! Please login.</p>';
    }
    ?>
    <p>Don't have an account? <a href="signup.php">Sign up here</a></p>
    <a href="index.php">Homepage</a>
</body>
</html>
