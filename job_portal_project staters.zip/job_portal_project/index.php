<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Job Portal</title>
    <link rel="stylesheet" href="style/index.css">
</head>
<body>

<nav>
    <div class="logo">JobPortal</div>
    <div class="nav-links">
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="signup.php">Sign Up</a>
        <a href="login.php">Login</a>
    </div>
</nav>

<div class="container">
    <h1>Welcome to Job Portal</h1>
    <p>Your gateway to exciting career opportunities!</p>

    <a href="signup.php" class="btn">Sign Up</a>
    <a href="login.php" class="btn">Login</a>

    <!-- <img src="" alt="Jobs and Careers"> -->
</div>

<footer>
    &copy; <?= date("Y") ?> JobPortal. All rights reserved. |
    <a href="about.php">About</a> |
    <a href="contact.php">Contact</a>
</footer>

</body>
</html>
