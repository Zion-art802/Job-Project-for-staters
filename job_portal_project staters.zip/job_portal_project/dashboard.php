<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Optional: pull user info
$fname = $_SESSION['fname'];
$lname = $_SESSION['lname'];
?>

<!DOCTYPE html>
<html>
<head>
    <script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>

    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            padding: 20px 40px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        .welcome {
            font-size: 16px;
            font-weight: bold;
        }

        .logout {
            background-color: #e74c3c;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .search-form {
            margin: 30px auto;
            text-align: center;
        }

        .search-input {
            width: 300px;
            padding: 10px;
            font-size: 14px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .search-button {
            padding: 10px 15px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin-left: 10px;
        }

        .job-card {
            background-color: white;
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>

<!-- ✅ Welcome + Logout -->
<div class="top-bar">
    <div class="welcome">
        Welcome, <?= htmlspecialchars($fname . " " . $lname) ?>
    </div>
    <a href="logout.php" class="logout">Logout</a>
</div>

<!-- ✅ Search Form -->
<div class="search-form">
    <form method="GET" action="">
        <input type="text" name="search" class="search-input"
               placeholder="Search by job title, company, location"
               value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        <button type="submit" class="search-button">Search</button>
    </form>
</div>

<!-- ✅ Job Listings -->
<?php
$search = $_GET['search'] ?? '';
$sql = "SELECT * FROM jobs";

if (!empty($search)) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE title LIKE '%$search%' OR company LIKE '%$search%' OR location LIKE '%$search%'";
}

$sql .= " ORDER BY id DESC";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($job = $result->fetch_assoc()) {
        echo "
        <div class='job-card'>
            <h3>{$job['title']}</h3>
            <p><strong>Company:</strong> {$job['company']}</p>
            <p><strong>Location:</strong> {$job['location']}</p>
            <a href='apply.php?job_id={$job['id']}' class='search-button'>Apply</a>
        </div>
        ";
    }
} else {
    echo "<p style='text-align:center;'>No jobs found.</p>";
}
?>

</body>
</html>
 