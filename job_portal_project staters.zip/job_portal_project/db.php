<?php
// db.php - Database connection
$host = "localhost";
$user = "root";
$password = "Zion@1234"; // Change if you use a password
$database = "job_portal";

$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
